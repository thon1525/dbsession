<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class DatabaseController extends Controller
{
    public function makesession(){
        $resurt= DB::table("tbluser")->get();
       
        foreach($resurt as $obj){
             foreach ($resurt as $obj){
              $onedb= $obj->password;
              $twodb= $obj->username;
         }
         $makesessionid= session('key', $onedb);
          $makesessionname= session('key',  $twodb);
          $datasession = [
                 'username'=> $makesessionname,
                 'userid'=>  $makesessionid
          ];
          return view('makeaccout',$datasession);
        }
    }
}
