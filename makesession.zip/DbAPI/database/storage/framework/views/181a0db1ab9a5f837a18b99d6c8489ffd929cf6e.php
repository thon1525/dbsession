<?php echo e($userid); ?>

<br>
<?php echo e($username); ?><?php /**PATH D:\laravel\DbCrud\DbAPI\database\resources\views/makeaccout.blade.php ENDPATH**/ ?>